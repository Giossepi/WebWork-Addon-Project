The WebWork Addon Project (WAP) is designed to improve the user experience of the WebWork platform 
via the integration of helper features such as a live preview, resizing input boxes, and macros for 
commonly used formats. This project is provided as is with no warrenty or guarantee of service.
Currently this is built as a firefox addon and can be loaded by keeping both files (the manifest and the js file)
and going to 'about:debugging' in firefox and loading this as a temporary addon for testing.
Again this is unfinished and largely untested, please verify the live preview before submission.
If any discrepencies are found please go to the projects GitHub ( https://github.com/Giossepi/WebWork-Addon-Project )
and create a discussion. Thank you for using the WebWork Addon Project, I hope it makes you hate WebWork less then I do!
